# -*- coding: utf-8 -*-
"""霓虹疾驰 Neon Dash —— pygbag 网页版入口（浏览器内运行）。
桌面版仍用 main.py（exe 打包不变），此文件仅供 pygbag 编译 wasm 用。"""
import asyncio
import sys

# 网页版：SDL 用虚拟驱动，事件由 pygbag 桥接
import pygame

from config import FPS, TITLE, H, W


async def main():
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    pygame.display.set_caption(TITLE)
    screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()

    from game import Game
    g = Game(screen)

    while True:
        dt = min(clock.tick(FPS) / 1000.0, 1 / 45.0)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            elif e.type == pygame.KEYDOWN:
                g.handle_keydown(e.key)
            elif e.type == pygame.MOUSEMOTION:
                g.handle_mouse_motion(e.pos)
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                g.handle_mouse_down(e.pos)
        g.update(dt)
        g.draw()
        # 让出主线程给浏览器渲染（pygbag 必需）
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
