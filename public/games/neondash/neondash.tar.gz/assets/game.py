# -*- coding: utf-8 -*-
"""游戏主体：状态机（主菜单/倒计时/奔跑/死亡/结算/暂停）、HUD、粒子、碰撞、道具"""
import math
import random

import pygame

import ui
from config import (ACCEL, BUFF_MAGNET_T, BUFF_X2_T, CAM_DIST, COL, COIN_VALUE,
                    DIST_SCORE_RATE, DRAW_DIST, FOCAL_BASE, FPS, GATE_CLEAR,
                    HIT_HALF, HORIZON, HURDLE_CLEAR, LANE_HIT_X, LANES,
                    SPEED_MAX, SPEED_START, TITLE, W, H, clamp, lerp, project)
from player import Player
from savegame import SaveGame
from sfx import SFX
from world import COIN, MAGNET, SHIELD, X2, Pickup, World

MENU, COUNTDOWN, RUN, DYING, OVER, PAUSE = ("menu", "count", "run",
                                            "dying", "over", "pause")


def ease_out_back(x):
    c1, c3 = 1.70158, 2.70158
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


class Particles:
    def __init__(self):
        self.list = []

    def burst(self, x, y, col, n=12, spd=260, size=4, grav=520, life=0.7):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            v = random.uniform(spd * 0.35, spd)
            self.list.append({
                "x": x, "y": y, "vx": math.cos(a) * v,
                "vy": math.sin(a) * v - spd * 0.25,
                "life": random.uniform(life * 0.5, life), "max": life,
                "col": col, "size": random.uniform(size * 0.5, size),
                "grav": grav})

    def update(self, dt):
        out = []
        for p in self.list:
            p["life"] -= dt
            if p["life"] > 0:
                p["vy"] += p["grav"] * dt
                p["x"] += p["vx"] * dt
                p["y"] += p["vy"] * dt
                out.append(p)
        self.list = out

    def draw(self, surf):
        for p in self.list:
            k = clamp(p["life"] / p["max"], 0, 1)
            r = max(1, int(p["size"] * k + 0.5))
            c = tuple(int(v * k + 26 * (1 - k)) for v in p["col"])
            pygame.draw.circle(surf, c, (int(p["x"]), int(p["y"])), r)


class Game:
    def __init__(self, screen):
        self.screen = screen
        self.sfx = SFX()
        self.save = SaveGame()
        self.world = World()
        self.player = Player()
        self.parts = Particles()
        self.wsurf = pygame.Surface((W, H))
        self.state = MENU
        self.t = 0.0
        self.menu_dist = 0.0
        self.help_open = False
        # 运行时数据
        self.dist = 0.0
        self.speed = SPEED_START
        self.score_f = 0.0
        self.coins = 0
        self.buffs = {SHIELD: 0.0, MAGNET: 0.0, X2: 0.0}
        self.count_t = 0.0
        self.die_t = 0.0
        self.flash_t = 0.0
        self.shake_t = 0.0
        self.shake_dur = 0.001
        self.shake_amp = 0
        self.hint_t = 0.0
        self.new_record = False
        self.final_score = 0
        self.final_dist = 0.0
        self.over_t = 0.0
        self.record_pulse = 0.0
        self.confetti_t = 0.0
        # 焦点
        self.focus = {"menu": 0, "pause": 0, "over": 0}
        self._make_vignette()
        self._make_buttons()

    # ---------------- 按钮 ----------------
    def _make_buttons(self):
        mk = ui.Button
        self.btns = {
            "menu": [
                mk((W // 2, 448), "开 始 游 戏", 30, 360, 64, lambda tag: self._click_menu(tag), "start"),
                mk((W // 2, 526), "操 作 说 明", 26, 360, 58, lambda tag: self._click_menu(tag), "help"),
                mk((W // 2, 600), "退 出", 26, 360, 58, lambda tag: self._click_menu(tag), "quit"),
            ],
            "pause": [
                mk((W // 2, 330), "继 续", 27, 330, 58, lambda tag: self._click_pause(tag), "resume"),
                mk((W // 2, 402), "重新开始", 25, 330, 56, lambda tag: self._click_pause(tag), "restart"),
                mk((W // 2, 472), "音效：开", 25, 330, 56, lambda tag: self._click_pause(tag), "sound"),
                mk((W // 2, 542), "返回主菜单", 25, 330, 56, lambda tag: self._click_pause(tag), "menu"),
            ],
            "over": [
                mk((W // 2 + 8, 556), "再 来 一 次", 26, 300, 56, lambda tag: self._click_over(tag), "retry"),
                mk((W // 2 + 8, 624), "返回主菜单", 23, 300, 52, lambda tag: self._click_over(tag), "menu"),
            ],
        }

    def _active(self):
        if self.state == MENU:
            return [] if self.help_open else self.btns["menu"]
        if self.state == PAUSE:
            return self.btns["pause"]
        if self.state == OVER:
            return self.btns["over"]
        return []

    def _key_of(self, group, idx):
        b = self.btns[group]
        return b[idx].tag if 0 <= idx < len(b) else None

    # ---------------- 流程控制 ----------------
    def start_run(self):
        self.player.reset()
        self.world.reset(0.0)
        self.parts.list.clear()
        self.dist = 0.0
        self.speed = SPEED_START
        self.score_f = 0.0
        self.coins = 0
        self.buffs = {SHIELD: 0.0, MAGNET: 0.0, X2: 0.0}
        self.count_t = 3.65
        self.hint_t = 5.0
        self.new_record = False
        self.flash_t = 0.0
        self.state = COUNTDOWN

    def goto_menu(self):
        self.state = MENU
        self.help_open = False

    def pause_toggle(self):
        if self.state == RUN:
            self.state = PAUSE
            self.focus["pause"] = 0
        elif self.state == PAUSE:
            self.state = RUN

    def mult(self):
        return 2 if self.buffs[X2] > 0 else 1

    def shake(self, dur, amp):
        self.shake_dur = max(dur, 0.001)
        self.shake_t = dur
        self.shake_amp = amp

    # ---------------- 点击回调 ----------------
    def _click_menu(self, tag):
        self.sfx.play("click")
        if tag == "start":
            self.start_run()
        elif tag == "help":
            self.help_open = True
        elif tag == "quit":
            pygame.event.post(pygame.event.Event(pygame.QUIT))

    def _click_pause(self, tag):
        self.sfx.play("click")
        if tag == "resume":
            self.state = RUN
        elif tag == "restart":
            self.start_run()
        elif tag == "sound":
            on = self.sfx.toggle()
            self.btns["pause"][2].label = f"音效：{'开' if on else '关'}"
        elif tag == "menu":
            self.goto_menu()

    def _click_over(self, tag):
        self.sfx.play("click")
        if tag == "retry":
            self.start_run()
        elif tag == "menu":
            self.goto_menu()

    # ---------------- 输入 ----------------
    def handle_keydown(self, key):
        st = self.state
        if st == MENU:
            if self.help_open:
                self.help_open = False
                self.sfx.play("click")
                return
            group, n = "menu", len(self.btns["menu"])
            if key in (pygame.K_UP, pygame.K_w):
                self.focus[group] = (self.focus[group] - 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.focus[group] = (self.focus[group] + 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                self.btns[group][self.focus[group]].activate()
        elif st == COUNTDOWN:
            self._lane_keys(key)
        elif st == RUN:
            if key in (pygame.K_p, pygame.K_ESCAPE):
                self.pause_toggle()
                self.sfx.play("click")
                return
            if not self._lane_keys(key):
                pass
        elif st == PAUSE:
            group, n = "pause", len(self.btns["pause"])
            if key in (pygame.K_p, pygame.K_ESCAPE):
                self.pause_toggle()
                self.sfx.play("click")
                return
            if key in (pygame.K_UP, pygame.K_w):
                self.focus[group] = (self.focus[group] - 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.focus[group] = (self.focus[group] + 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_LEFT, pygame.K_a, pygame.K_RIGHT, pygame.K_d):
                if self._key_of(group, self.focus[group]) == "sound":
                    self.btns[group][self.focus[group]].activate()
            elif key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                self.btns[group][self.focus[group]].activate()
        elif st == OVER:
            group, n = "over", len(self.btns["over"])
            if key == pygame.K_r:
                self.start_run()
                return
            if key in (pygame.K_ESCAPE, pygame.K_m):
                self.goto_menu()
                return
            if key in (pygame.K_UP, pygame.K_LEFT, pygame.K_w, pygame.K_a):
                self.focus[group] = (self.focus[group] - 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_DOWN, pygame.K_RIGHT, pygame.K_s, pygame.K_d):
                self.focus[group] = (self.focus[group] + 1) % n
                self.sfx.play("switch")
            elif key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                self.btns[group][self.focus[group]].activate()

    def _lane_keys(self, key):
        pl = self.player
        if key in (pygame.K_LEFT, pygame.K_a):
            if pl.move_left():
                self.sfx.play("switch")
            return True
        if key in (pygame.K_RIGHT, pygame.K_d):
            if pl.move_right():
                self.sfx.play("switch")
            return True
        if key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
            if pl.jump():
                self.sfx.play("jump")
            return True
        if key in (pygame.K_DOWN, pygame.K_s):
            if pl.down():
                self.sfx.play("switch")
            return True
        return False

    def handle_mouse_motion(self, pos):
        grp = self._grp()
        for i, b in enumerate(self._active()):
            if b.contains(pos):
                b.focused = True
                self.focus[grp] = i
            else:
                b.focused = False

    def handle_mouse_down(self, pos):
        grp = self._grp()
        for i, b in enumerate(self._active()):
            if b.contains(pos):
                self.focus[grp] = i
                b.activate()
                return True
        if self.state == MENU and self.help_open:
            self.help_open = False
        return False

    def _grp(self):
        if self.state == MENU:
            return "menu"
        if self.state == PAUSE:
            return "pause"
        if self.state == OVER:
            return "over"
        return "menu"

    # ---------------- 死亡 ----------------
    def die(self):
        self.player.alive = False
        self.state = DYING
        self.die_t = 0.0
        self.flash_t = 0.4
        self.final_score = int(self.score_f)
        self.final_dist = self.dist
        self.new_record = self.save.submit(self.final_score, self.final_dist,
                                           self.coins)
        self.shake(0.6, 15)
        s, sx, sy = project(self.player.x, 0.9, 0, FOCAL_BASE, W / 2)
        for c in (COL["cyan"], COL["pink"], COL["yellow"], COL["white"]):
            self.parts.burst(sx, sy, c, 12, 430, 5, 620, 0.9)
        self.sfx.play("crash")

    # ---------------- 更新 ----------------
    def update(self, dt):
        self.t += dt
        if self.shake_t > 0:
            self.shake_t = max(0.0, self.shake_t - dt)
        if self.flash_t > 0:
            self.flash_t = max(0.0, self.flash_t - dt)
        st = self.state
        if st == MENU:
            self.menu_dist += dt * 11.0
            self.parts.update(dt)
        elif st == COUNTDOWN:
            self.count_t -= dt
            self.dist += dt * SPEED_START * 0.32
            self.world.fill(self.dist, self.speed)
            self.player.update(dt, SPEED_START * 0.4)
            self.parts.update(dt)
            if self.count_t <= 0:
                self.state = RUN
                self.sfx.play("power")
        elif st == RUN:
            self._update_run(dt)
        elif st == DYING:
            self.die_t += dt
            self.parts.update(dt)
            if self.die_t >= 1.05:
                self.state = OVER
                self.over_t = 0.0
                self.focus["over"] = 0
                if self.new_record:
                    self.sfx.play("record")
        elif st == OVER:
            self.over_t = min(1.0, self.over_t + dt * 2.0)
            self.parts.update(dt)
            if self.new_record:
                self.confetti_t -= dt
                if self.confetti_t <= 0:
                    self.confetti_t = 0.16
                    x = random.uniform(W * 0.2, W * 0.8)
                    c = random.choice([COL["cyan"], COL["pink"],
                                       COL["yellow"], COL["green"]])
                    self.parts.burst(x, random.uniform(80, 240), c, 8, 200, 4, 380, 1.1)
        elif st == PAUSE:
            pass

    def _update_run(self, dt):
        self.speed = min(SPEED_MAX, self.speed + ACCEL * dt)
        self.dist += self.speed * dt
        self.score_f += self.speed * dt * DIST_SCORE_RATE * self.mult()
        self.hint_t -= dt
        pl = self.player
        pl.update(dt, self.speed)
        # 玩家动作反馈
        if pl.just_jumped:
            _, jx, jy = project(pl.x, 0.08, 0, FOCAL_BASE, self._cx(FOCAL_BASE))
            self.parts.burst(jx, jy, (170, 220, 255), 8, 170, 3, 380, 0.4)
        if pl.just_landed:
            _, fx, fy = project(pl.x, 0.05, 0, FOCAL_BASE, self._cx(FOCAL_BASE))
            self.parts.burst(fx, fy, (140, 200, 255), 7, 130, 3, 420, 0.45)
        self.world.fill(self.dist, self.speed)
        # 磁铁吸附
        if self.buffs[MAGNET] > 0:
            for pk in self.world.pickups:
                rel = pk.T - self.dist
                if pk.kind == COIN and not pk.taken and -1.0 < rel < 9.5:
                    k = min(1.0, dt * 7.0)
                    pk.x += (pl.x - pk.x) * k
                    pk.y += ((pl.y + pl.height() * 0.5) - pk.y) * k
        # 障碍碰撞
        for ob in self.world.obstacles:
            rel = ob.T - self.dist
            if -HIT_HALF <= rel <= HIT_HALF:
                dx = abs(pl.x - LANES[ob.lane])
                if dx > LANE_HIT_X:
                    continue
                hit = False
                if ob.kind == "hurdle":
                    hit = pl.y < HURDLE_CLEAR
                elif ob.kind == "gate":
                    hit = (pl.y + pl.height()) > GATE_CLEAR
                else:
                    hit = True
                if not hit or pl.inv_t > 0:
                    continue
                if self.buffs[SHIELD] > 0:
                    self.buffs[SHIELD] = 0.0
                    pl.inv_t = 1.5
                    ob.T = -10 ** 9  # 移除
                    s, sx, sy = project(LANES[ob.lane], 1.0, rel, self._fc(), self._cx(self._fc()))
                    self.parts.burst(sx, sy, COL["cyan"], 22, 330, 5, 480, 0.7)
                    self.sfx.play("power")
                else:
                    self.die()
                    return
        # 拾取
        for pk in self.world.pickups:
            if pk.taken:
                continue
            rel = pk.T - self.dist
            if abs(rel) > 0.95:
                continue
            dx = abs(pk.x - pl.x)
            dy = abs(pk.y - (pl.y + pl.height() * 0.5))
            rx = 1.05 if pk.kind == COIN else 1.25
            if dx <= rx and dy <= (1.15 if pk.kind == COIN else 1.5):
                pk.taken = True
                s, sx, sy = project(pk.x, pk.y, rel, self._fc(), self._cx(self._fc()))
                if pk.kind == COIN:
                    self.coins += 1
                    self.score_f += COIN_VALUE * self.mult()
                    self.parts.burst(sx, sy, (255, 214, 80), 7, 190, 3, 380, 0.5)
                    self.sfx.play("coin")
                else:
                    if pk.kind == SHIELD:
                        self.buffs[SHIELD] = 99999.0
                    elif pk.kind == MAGNET:
                        self.buffs[MAGNET] = BUFF_MAGNET_T
                    else:
                        self.buffs[X2] = BUFF_X2_T
                    cc = {SHIELD: COL["cyan"], MAGNET: COL["pink"], X2: COL["yellow"]}[pk.kind]
                    self.parts.burst(sx, sy, cc, 16, 280, 4, 430, 0.7)
                    self.sfx.play("power")
        # 道具计时
        for kk in (MAGNET, X2):
            if self.buffs[kk] > 0:
                self.buffs[kk] = max(0.0, self.buffs[kk] - dt)

    # ---------------- 渲染辅助 ----------------
    def _fc(self):
        """当前焦距（速度越快轻微广角）"""
        ramp = clamp((self.speed - SPEED_START) / (SPEED_MAX - SPEED_START), 0, 1)
        if self.state in (MENU,):
            return FOCAL_BASE
        return FOCAL_BASE * (1.0 - 0.08 * ramp)

    def _cx(self, focal):
        return W / 2 - self.player.x * focal / CAM_DIST * 0.20

    def _make_vignette(self):
        v = pygame.Surface((W, H), pygame.SRCALPHA)
        for i in range(34):
            k = i / 34.0
            inset = int(k * 240)
            alpha = int(3 + 10 * (1 - k))
            r = pygame.Rect(inset, inset - int(k * 80), W - inset * 2, H - inset * 2 + int(k * 120))
            pygame.draw.rect(v, (5, 2, 14, alpha), r, width=18,
                             border_radius=60 + int(k * 120))
        self.vignette = v

    # ---------------- 主绘制 ----------------
    def draw(self):
        scr = self.screen
        scr.fill((4, 2, 10))
        focal = self._fc()
        cx = self._cx(focal)
        dist_for_bg = self.menu_dist if self.state == MENU else self.dist
        ws = self.wsurf
        if self.state in (MENU, COUNTDOWN, RUN, DYING, OVER, PAUSE):
            self.world.draw_background(ws, self.t)
            self.world.draw_ground(ws, dist_for_bg, focal, cx)
            self.world.draw_scenery(ws, dist_for_bg, focal, cx, self.t)
            self.world.draw_entities(ws, dist_for_bg, focal, cx, self.t)
            if self.state not in (MENU, OVER) and self.player.alive:
                self.player.draw(ws, focal, cx, self.t)
            self.parts.draw(ws)
        # 抖动
        ox = oy = 0
        if self.shake_t > 0:
            k = self.shake_t / self.shake_dur
            amp = self.shake_amp * k
            ox = random.uniform(-amp, amp)
            oy = random.uniform(-amp, amp)
        scr.blit(ws, (ox, oy))
        scr.blit(self.vignette, (0, 0))
        st = self.state
        if st == MENU:
            self._draw_menu()
        elif st == COUNTDOWN:
            self._draw_hud()
            self._draw_countdown()
        elif st == RUN:
            self._draw_hud()
        elif st == DYING:
            self._draw_hud()
            self._draw_crash()
        elif st == OVER:
            self._draw_over()
        elif st == PAUSE:
            self._draw_hud()
            self._draw_pause()
        if self.flash_t > 0:
            fl = pygame.Surface((W, H), pygame.SRCALPHA)
            fl.fill((255, 40, 60, int(150 * self.flash_t / 0.4)))
            scr.blit(fl, (0, 0))
        pygame.display.flip()

    # ---------------- 各界面 ----------------
    def _draw_menu(self):
        scr = self.screen
        t = self.t
        bob = math.sin(t * 1.6) * 6
        ui.chroma_title(scr, "霓虹疾驰", 96, (W // 2, 176 + bob))
        ui.glow_text(scr, "N  E  O  N     D  A  S  H", 30, (W // 2, 250 + bob),
                     COL["cyan"], rings=4)
        ui.shadow_text(scr, "- 三 道 路 · 无 尽 狂 奔 -", 20, (W // 2, 292 + bob),
                       (170, 160, 220))
        # 顶部装饰线
        pygame.draw.line(scr, COL["pink"], (W / 2 - 240, 318 + bob), (W / 2 + 240, 318 + bob), 2)
        # 按钮
        grp = "menu"
        for i, b in enumerate(self.btns[grp]):
            b.focused = (i == self.focus[grp]) and not self.help_open
            b.draw(scr, t)
        # 底部信息
        bs = self.save
        ui.shadow_text(scr,
                       f"最高分 {bs.best_score}    最远 {bs.best_distance:g} m    已奔跑 {bs.data['games']} 局",
                       22, (W // 2, 668), COL["dim"])
        ui.shadow_text(scr, "←→ 切道 · 空格跳跃 · ↓ 下滑 · P 暂停", 18,
                       (W // 2, 700), (110, 100, 160))
        if self.help_open:
            self._draw_help()

    def _draw_help(self):
        scr = self.screen
        rect = pygame.Rect(0, 0, 720, 460)
        rect.center = (W // 2, H // 2 - 10)
        ui.neon_panel(scr, rect, COL["cyan"], fill_alpha=96)
        ui.glow_text(scr, "操 作 说 明", 40, (rect.centerx, rect.y + 62), COL["cyan"])
        rows = [
            ("← / →  或  A / D", "切换跑道"),
            ("空格 / ↑ / W", "跳 跃（可越过跨栏）"),
            ("↓ / S", "下滑（可钻过吊门）· 空中按下急坠落地滑铲"),
            ("P 或 Esc", "暂停 / 继续"),
            ("", ""),
            ("粉色跨栏 → 跳过", "黄色吊门 → 滑铲钻过"),
            ("紫色高墙 → 变道躲避", "金色六边形 = 能量"),
            ("护盾：抵挡一次撞击", "磁铁：自动吸取能量 · ×2：分数加倍"),
        ]
        y = rect.y + 128
        for k, v in rows:
            if k:
                ui.shadow_text(scr, k, 24, (rect.x + 210, y), COL["white"])
                ui.shadow_text(scr, v, 22, (rect.x + 500, y), COL["dim"])
            y += 40
        ui.shadow_text(scr, "按任意键返回", 19, (rect.centerx, rect.bottom - 34),
                       (120, 210, 230))

    def _draw_countdown(self):
        scr = self.screen
        ct = self.count_t
        if ct > 3.2:
            return
        if ct > 0.35:
            n = str(int(math.ceil(ct)))
            frac = ct - int(ct)
            scale = 1.0 + max(0.0, frac - 0.6) * 1.6
            size = int(150 * scale)
            ui.chroma_title(scr, n, size, (W // 2, int(H * 0.42)))
        else:
            ui.glow_text(scr, "GO !", 120, (W // 2, int(H * 0.42)),
                         COL["green"], rings=8)

    def _draw_crash(self):
        scr = self.screen
        if self.die_t > 0.25:
            jx = random.randint(-4, 4) if self.die_t < 0.7 else 0
            ui.glow_text(scr, "撞 击 !", 84, (W // 2 + jx, int(H * 0.36)),
                         COL["danger"], rings=7)

    def _draw_hud(self):
        scr = self.screen
        # 左上：分数 / 距离
        ui.shadow_text(scr, "分数", 20, (86, 40), (150, 140, 200))
        sc = str(int(self.score_f))
        ui.glow_text(scr, sc, 52, (88, 82), COL["white"], rings=3)
        ui.shadow_text(scr, f"距离 {self.dist:,.0f} m", 24, (108, 136),
                       COL["cyan"])
        # 增益状态条
        yy = 172
        infos = [(SHIELD, "护盾", COL["cyan"], None),
                 (MAGNET, "磁铁", COL["pink"], BUFF_MAGNET_T),
                 (X2, "×2 分数", COL["yellow"], BUFF_X2_T)]
        for kind, lab, col, total in infos:
            v = self.buffs[kind]
            if v <= 0:
                continue
            bx, bw = 40, 150
            ui.shadow_text(scr, lab, 19, (bx + 26, yy), col)
            frac = 1.0 if total is None else clamp(v / total, 0, 1)
            pygame.draw.rect(scr, (60, 50, 100), (bx + 58, yy - 6, bw, 10),
                             border_radius=5)
            pygame.draw.rect(scr, col, (bx + 58, yy - 6, bw * frac, 10),
                             border_radius=5)
            if total is None:
                ui.shadow_text(scr, "∞", 18, (bx + bw + 76, yy), col)
            yy += 30
        # 右上：能量 / 最佳
        hx, hy = W - 150, 66
        pts = [(hx + math.cos(math.pi / 6 + k * math.pi / 3) * 13,
                hy + math.sin(math.pi / 6 + k * math.pi / 3) * 13) for k in range(6)]
        pygame.draw.polygon(scr, (255, 208, 64), pts)
        pygame.draw.polygon(scr, (255, 245, 200), pts, 2)
        ui.shadow_text(scr, f"× {self.coins}", 30, (W - 96, hy), COL["white"])
        ui.shadow_text(scr, f"最佳 {self.save.best_score}", 21, (W - 106, 112),
                       (170, 160, 220))
        # 右下：速度表
        ramp = clamp((self.speed - SPEED_START) / (SPEED_MAX - SPEED_START), 0, 1)
        gx, gy = W - 268, H - 52
        ui.shadow_text(scr, "速 度", 17, (gx + 20, gy - 16), (150, 140, 200))
        cells = 12
        for i in range(cells):
            on = (i / cells) <= ramp + 1e-4
            c = COL["cyan"] if i < cells * 0.6 else (
                COL["yellow"] if i < cells * 0.85 else COL["pink"]) if on else (52, 40, 88)
            pygame.draw.rect(scr, c, (gx + i * 18, gy, 14, 16), border_radius=3)
        # 底部操作提示
        if self.hint_t > 0 and self.state == RUN:
            a = clamp(self.hint_t, 0, 1)
            tmp = pygame.Surface((W, 30), pygame.SRCALPHA)
            img = ui.text_surf("←→ 切道 · 空格 跳跃 · ↓ 下滑 · P 暂停", 20,
                               (180, 175, 230))
            tmp.blit(img, (W // 2 - img.get_width() // 2, 4))
            tmp.set_alpha(int(220 * a))
            scr.blit(tmp, (0, H - 34))

    def _draw_pause(self):
        scr = self.screen
        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((6, 3, 16, 165))
        scr.blit(ov, (0, 0))
        rect = pygame.Rect(0, 0, 460, 444)
        rect.center = (W // 2, H // 2)
        ui.neon_panel(scr, rect, COL["purple"], fill_alpha=100)
        ui.glow_text(scr, "暂 停", 52, (rect.centerx, rect.y + 74), COL["purple"])
        self.btns["pause"][2].label = f"音效：{'开' if self.sfx.enabled else '关'}"
        for i, b in enumerate(self.btns["pause"]):
            b.focused = i == self.focus["pause"]
            b.draw(scr, self.t)

    def _draw_over(self):
        scr = self.screen
        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((6, 3, 16, 185))
        scr.blit(ov, (0, 0))
        k = ease_out_back(self.over_t)
        ph = (H - 560) / 2
        rect = pygame.Rect(0, 0, 560, 560)
        rect.center = (W // 2, int(ph + 280))
        off_y = int((1 - k) * 300)
        rect = rect.move(0, off_y)
        ui.neon_panel(scr, rect, COL["pink"] if self.new_record else COL["cyan"],
                      fill_alpha=104)
        cy = rect.y
        ui.glow_text(scr, "跑 完 了 !", 46, (rect.centerx, cy + 66),
                     COL["pink"] if self.new_record else COL["cyan"])
        # 新纪录徽章
        if self.new_record:
            pul = 0.75 + 0.25 * math.sin(self.t * 7)
            bw = pygame.Rect(0, 0, 190, 44)
            bw.center = (rect.right - 108, cy + 132)
            tmp = pygame.Surface(bw.size, pygame.SRCALPHA)
            pygame.draw.rect(tmp, (255, 45, 150, int(200 * pul)),
                             tmp.get_rect(), border_radius=22)
            scr.blit(tmp, bw.topleft)
            ui.shadow_text(scr, "★ 新纪录 ★", 24, bw.center, COL["white"])
        ui.shadow_text(scr, "本次得分", 22, (rect.centerx - 120, cy + 138),
                       (170, 160, 220))
        ui.glow_text(scr, f"{self.final_score:,}", 72,
                     (rect.centerx, cy + 205), COL["yellow"])
        rows = [("奔跑距离", f"{self.final_dist:,.0f} m"),
                ("收集能量", f"{self.coins}"),
                ("历史最佳", f"{self.save.best_score:,}")]
        yy = cy + 272
        for lab, val in rows:
            ui.shadow_text(scr, lab, 23, (rect.x + 130, yy), (160, 150, 210))
            ui.shadow_text(scr, val, 25, (rect.right - 160, yy), COL["white"])
            pygame.draw.line(scr, (70, 55, 120), (rect.x + 60, yy + 22),
                             (rect.right - 60, yy + 22), 1)
            yy += 42
        for i, b in enumerate(self.btns["over"]):
            b.rect.centery += off_y  # 面板滑动同步
            b.focused = i == self.focus["over"]
            b.draw(scr, self.t)
            b.rect.centery -= off_y
