# -*- coding: utf-8 -*-
"""霓虹疾驰 Neon Dash - 全局配置 / 调色板 / 投影工具"""
import math

# ---------------- 窗口 ----------------
W, H = 1280, 720
FPS = 60
TITLE = "霓虹疾驰 Neon Dash"

# ---------------- 跑道 / 相机 ----------------
LANES = (-2.2, 0.0, 2.2)      # 三条车道的世界 X 坐标
LANE_SPACING = 2.2
LANE_HIT_X = 1.25             # 横向碰撞判定半宽（略小于半道宽，留宽容）
ROAD_HALF = 3.6               # 路面视觉半宽
CAM_DIST = 7.0                # 相机位于玩家身后多少世界单位
CAM_H = 3.1                   # 相机高度
HORIZON = int(H * 0.38)       # 地平线屏幕 Y
FOCAL_BASE = int(H * 1.05)    # 基准焦距
DRAW_DIST = 95                # 前方绘制距离（世界单位）

# ---------------- 物理 ----------------
GRAVITY = 30.0
JUMP_V = 10.4                 # 起跳初速 → 跳高约 1.8
SLIDE_T = 0.62                # 下滑持续秒数
SLAM_V = -24.0                # 空中按下时的急坠速度
H_STAND = 1.8                 # 站立身高
H_SLIDE = 0.85                # 滑铲身高
HURDLE_CLEAR = 0.95           # 跨栏顶高度：脚高于此值可通过
GATE_CLEAR = 1.15             # 吊门下沿：头顶低于此值可通过
WALL_H = 2.6                  # 高墙高度（不可越过）

HIT_HALF = 0.85               # 纵向碰撞判定半深

# ---------------- 速度 / 计分 ----------------
SPEED_START = 13.0
SPEED_MAX = 34.0
ACCEL = 0.30                  # 每秒加速度
COIN_VALUE = 40               # 单枚能量价值
DIST_SCORE_RATE = 10.0        # 每 world-unit 距离换算分数
BUFF_MAGNET_T = 8.0
BUFF_X2_T = 8.0

# ---------------- 调色板（霓虹赛博） ----------------
COL = {
    "bg_top":     (10, 7, 26),
    "bg_mid":     (34, 13, 62),
    "bg_low":     (58, 19, 88),
    "ground":     (17, 9, 33),
    "road":       (27, 14, 52),
    "grid":       (96, 52, 170),
    "rail_cyan":  (0, 229, 255),
    "rail_pink":  (255, 45, 150),
    "pink":       (255, 45, 150),
    "cyan":       (0, 229, 255),
    "purple":     (172, 82, 255),
    "yellow":     (255, 228, 92),
    "green":      (57, 255, 140),
    "white":      (240, 245, 255),
    "dim":        (140, 130, 190),
    "panel":      (16, 10, 38),
    "danger":     (255, 70, 90),
}


def clamp(v, a, b):
    return a if v < a else b if v > b else v


def lerp(a, b, t):
    return a + (b - a) * t


def fog_col(col, rel):
    """按距离把颜色向背景色衰减（雾效），rel 为离玩家平面的距离"""
    t = clamp(rel / DRAW_DIST, 0.0, 1.0) ** 1.5 * 0.86
    return (int(col[0] + (34 - col[0]) * t),
            int(col[1] + (16 - col[1]) * t),
            int(col[2] + (54 - col[2]) * t))


def pseudo_rand(n):
    """由整数索引生成 0~1 的确定性伪随机数（用于路边景物）"""
    x = math.sin(n * 127.1 + 311.7) * 43758.5453
    return x - math.floor(x)


def project(x, y, z, focal, cx=None):
    """伪 3D 投影：世界 (x, y, z) → 屏幕坐标。z 为相对玩家平面的前向距离。
    返回 (缩放系数 s, 屏幕x, 屏幕y)。地面 y=0，向上为正。"""
    if cx is None:
        cx = W / 2
    s = focal / (z + CAM_DIST)
    sx = cx + x * s
    sy = HORIZON + (CAM_H - y) * s
    return s, sx, sy
