# -*- coding: utf-8 -*-
"""玩家：三车道移动 / 跳跃 / 滑铲 / 急坠 物理与几何渲染"""
import math
from collections import deque

import pygame

from config import (CAM_DIST, GRAVITY, H_SLIDE, H_STAND, JUMP_V, LANES,
                    SLAM_V, SLIDE_T, clamp, project)

_DARK = (30, 60, 96)
_MID = (58, 150, 210)
_BRIGHT = (120, 235, 255)
_TRIM = (255, 70, 170)


def _capsule(surf, p1, p2, w, col):
    """圆角胶囊肢体"""
    pygame.draw.line(surf, col, p1, p2, max(2, int(w)))
    r = max(2, int(w / 2))
    pygame.draw.circle(surf, col, (int(p1[0]), int(p1[1])), r)
    pygame.draw.circle(surf, col, (int(p2[0]), int(p2[1])), r)


class Player:
    def __init__(self):
        self.reset()

    def reset(self):
        self.target_lane = 1
        self.x = 0.0
        self.y = 0.0
        self.vy = 0.0
        self.grounded = True
        self.slide_t = 0.0
        self.pending_slide = False
        self.stride = 0.0
        self.inv_t = 0.0
        self.alive = True
        self.just_landed = False
        self.just_jumped = False
        self.just_slid = False
        self.just_switched = 0  # -1 左 / +1 右（供音效）
        self.trail = deque(maxlen=6)
        self._trail_timer = 0.0
        self.jump_buffer_t = 0.0   # 预输入缓冲：落地前短暂按跳，落地立即起跳

    # ---------- 操作 ----------
    def move_left(self):
        if self.alive and self.target_lane > 0:
            self.target_lane -= 1
            self.just_switched = -1
            return True
        return False

    def move_right(self):
        if self.alive and self.target_lane < 2:
            self.target_lane += 1
            self.just_switched = 1
            return True
        return False

    def jump(self):
        if not self.alive:
            return False
        if self.slide_t > 0:
            self.slide_t = 0.0
        if self.grounded:
            self.vy = JUMP_V
            self.grounded = False
            self.just_jumped = True
            return True
        # 空中按下：进入预输入缓冲，落地瞬间自动起跳（提升手感）
        self.jump_buffer_t = 0.14
        self.pending_slide = False
        return True

    def down(self):
        if not self.alive:
            return False
        if not self.grounded:
            self.vy = min(self.vy, SLAM_V)
            self.pending_slide = True
            self.jump_buffer_t = 0.0
            return True
        if self.slide_t <= 0:
            self.slide_t = SLIDE_T
            self.just_slid = True
            return True
        return False

    def height(self):
        return H_SLIDE if self.slide_t > 0 else H_STAND

    # ---------- 更新 ----------
    def update(self, dt, speed):
        self.just_landed = False
        self.just_jumped = False
        self.just_slid = False
        self.just_switched = 0
        tx = LANES[self.target_lane]
        self.x += (tx - self.x) * min(1.0, dt * 13.0)
        if abs(tx - self.x) < 0.02:
            self.x = tx
        if self.jump_buffer_t > 0:
            self.jump_buffer_t -= dt
        if not self.grounded:
            self.vy -= GRAVITY * dt
            self.y += self.vy * dt
            if self.y <= 0.0:
                self.y = 0.0
                self.grounded = True
                self.just_landed = True
                if self.jump_buffer_t > 0:      # 预输入：落地立刻起跳
                    self.jump_buffer_t = 0.0
                    self.pending_slide = False
                    self.vy = JUMP_V
                    self.grounded = False
                    self.just_jumped = True
                else:
                    self.vy = 0.0
                    if self.pending_slide:
                        self.pending_slide = False
                        self.slide_t = SLIDE_T
                        self.just_slid = True
        if self.slide_t > 0:
            self.slide_t -= dt
            if self.slide_t < 0:
                self.slide_t = 0.0
        if self.inv_t > 0:
            self.inv_t -= dt
        self.stride += speed * dt
        # 残影采样
        self._trail_timer -= dt
        if self._trail_timer <= 0:
            self._trail_timer = 0.05
            self.trail.append((self.x, self.y, self.slide_t > 0))

    # ---------- 渲染 ----------
    def draw(self, surf, focal, cx, t):
        s, sx, sy_ground = project(self.x, 0.0, 0.0, focal, cx)
        if s <= 0:
            return

        # 腾空拉伸 / 下落微压缩（果冻感），让跳跃弧线更醒目
        stretch = 1.0 + clamp(self.vy / JUMP_V, -0.3, 1.0) * 0.15

        def L(ox, oy):
            """局部坐标(横向ox, 离地高度oy) → 屏幕；叠加跳跃高度与拉伸"""
            return (sx + ox * s,
                    sy_ground - (oy * stretch + self.y) * s)

        # ---- 影子（随高度缩小变淡，强化腾空感）----
        shrink = clamp(1.0 - self.y / 3.0, 0.22, 1.0)
        sh_w = int(1.5 * s * shrink)
        tmp = pygame.Surface((sh_w * 2 + 8, int(sh_w * 0.6) + 8), pygame.SRCALPHA)
        pygame.draw.ellipse(tmp, (0, 0, 0, int(30 + 100 * shrink)), tmp.get_rect())
        surf.blit(tmp, (sx - tmp.get_width() / 2, sy_ground - tmp.get_height() / 2))

        # ---- 残影 ----
        n = len(self.trail)
        for i, (gx, gy, gsl) in enumerate(list(self.trail)[:-1]):
            age = (i + 1) / n
            gs, gsx, gsy = project(gx, 0.0, 0.0, focal, cx)
            top = gsy - (gy + (H_SLIDE * 0.7 if gsl else H_STAND * 0.92)) * gs
            bot = gsy - gy * gs
            col = (int(_MID[0] * (1 - age)), int(_MID[1] * (1 - age)),
                   int((_MID[2] + 40) * (1 - age)))
            pygame.draw.line(surf, col, (gsx, top), (gsx, bot),
                             max(2, int(0.30 * gs)))
        if len(self.trail):
            pass

        # 无敌闪烁
        if self.inv_t > 0 and int(t * 18) % 2 == 0:
            return

        # ---- 姿态关键点（世界单位）----
        ph = self.stride
        sliding = self.slide_t > 0
        air = not self.grounded

        if sliding:
            hip = (0.05, 0.34)
            sho = (0.38, 0.72)
            head = (0.52, 0.86)
            foot_f = (0.78, 0.06)
            knee_f = (0.48, 0.16)
            foot_b = (-0.42, 0.14)
            knee_b = (-0.18, 0.30)
            hand_f = (0.72, 0.44)
            elbow_f = (0.60, 0.56)
            hand_b = (-0.28, 0.10)
            elbow_b = (-0.05, 0.30)
        elif air:
            hip = (0.0, 0.92)
            sho = (0.04, 1.46)
            head = (0.06, 1.66)
            foot_f = (0.34, 0.52)
            knee_f = (0.30, 0.74)
            foot_b = (-0.26, 0.40)
            knee_b = (-0.16, 0.68)
            hand_f = (0.30, 1.62)
            elbow_f = (0.24, 1.50)
            hand_b = (-0.30, 1.30)
            elbow_b = (-0.22, 1.42)
        else:
            sw = math.sin(ph)
            cw = math.cos(ph)
            hip = (0.0, 0.94)
            sho = (math.copysign(0.03, sw), 1.47)
            head = (sho[0] * 2, 1.68)
            lift_f = max(0.0, cw) * 0.38
            lift_b = max(0.0, -cw) * 0.38
            foot_f = (sw * 0.46, 0.05 + lift_f)
            knee_f = (sw * 0.24, 0.52 + lift_f * 0.5)
            foot_b = (-sw * 0.46, 0.05 + lift_b)
            knee_b = (-sw * 0.24, 0.52 + lift_b * 0.5)
            hand_f = (-sw * 0.34, 1.02 + abs(sw) * 0.08)
            elbow_f = (-sw * 0.18, 1.26)
            hand_b = (sw * 0.34, 1.02 + abs(sw) * 0.08)
            elbow_b = (sw * 0.18, 1.26)

        # ---- 绘制（远→近：后臂 后腿 躯干 头 前腿 前臂）----
        bw = 0.11 * s   # 肢体粗细
        _capsule(surf, L(*elbow_b), L(*hand_b), bw, _DARK)
        _capsule(surf, L(*sho), L(*elbow_b), bw, _DARK)
        _capsule(surf, L(*hip), L(*knee_b), bw * 1.15, _DARK)
        _capsule(surf, L(*knee_b), L(*foot_b), bw, _DARK)
        # 躯干（渐层两段）
        _capsule(surf, L(*hip), L(*sho), 0.34 * s, _MID)
        _capsule(surf, L((hip[0] + sho[0]) / 2, (hip[1] + sho[1]) / 2),
                 L(*sho), 0.30 * s, _BRIGHT)
        # 能量腰带
        belt = (hip[0], hip[1] + 0.06)
        pygame.draw.circle(surf, _TRIM, L(*belt), max(2, int(0.09 * s)))
        # 头
        hc = L(*head)
        hr = int(0.155 * s)
        pygame.draw.circle(surf, _BRIGHT, hc, hr)
        pygame.draw.circle(surf, (235, 250, 255), (hc[0] + hr // 4, hc[1] - hr // 4), max(2, hr // 2))
        # 前腿 前臂
        _capsule(surf, L(*hip), L(*knee_f), bw * 1.2, _MID)
        _capsule(surf, L(*knee_f), L(*foot_f), bw, _BRIGHT)
        _capsule(surf, L(*sho), L(*elbow_f), bw, _TRIM)
        _capsule(surf, L(*elbow_f), L(*hand_f), bw * 0.9, _BRIGHT)
