# -*- coding: utf-8 -*-
"""UI 工具：字体加载、发光文字、霓虹面板、按钮"""
import math
import os

import pygame

from config import COL


# ---------------- 字体 ----------------
_FONT_CACHE = {}
# 打包进游戏资源目录的中文字体（网页版没有系统字体，靠它显示中文）
# 桌面版仍优先走系统字体（雅黑更好看），找不到时才回退到内置字体
_BUNDLED_CANDIDATES = [
    os.path.join("assets", "fonts", "wqy-microhei.ttc"),
    os.path.join("assets", "fonts", "wqy-microhei.ttf"),
]
_REG_CANDIDATES = ["msyh.ttc", "msyh.ttf", "msyhl.ttc", "simhei.ttf", "Deng.ttf"]
_BOLD_CANDIDATES = ["msyhbd.ttc", "msyh.ttf", "simhei.ttf", "DengB.ttf"]
_FONT_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
_found = {"reg": None, "bold": None}


def _locate(kind):
    if _found[kind]:
        return _found[kind]
    # 1) 内置打包字体（网页版唯一可用的中文字体源）
    for p in _BUNDLED_CANDIDATES:
        try:
            if os.path.exists(p):
                _found[kind] = p
                return p
        except Exception:
            pass
    # 2) 系统字体（桌面版）
    cands = _REG_CANDIDATES if kind == "reg" else _BOLD_CANDIDATES
    for name in cands:
        p = os.path.join(_FONT_DIR, name)
        try:
            if os.path.exists(p):
                _found[kind] = p
                return p
        except Exception:
            pass
    return None


def F(size, bold=False):
    """获取中文字体（优先内置打包字体/系统雅黑），带缓存"""
    key = (size, bold)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    path = _locate("bold" if bold else "reg")
    font = None
    if path:
        try:
            font = pygame.font.Font(path, size)
        except Exception:
            font = None
    if font is None:
        try:
            font = pygame.font.SysFont("microsoftyahei,simhei", size, bold=bold)
        except Exception:
            font = pygame.font.Font(None, size)
    # pygame 的 Font(None) 默认字体不含 CJK；都失败时用 set_bold 模拟加粗
    if bold and font is not None:
        try:
            font.set_bold(True)
        except Exception:
            pass
    _FONT_CACHE[key] = font
    return font


# ---------------- 文字 ----------------
def text_surf(text, size, color, bold=False):
    return F(size, bold).render(text, True, color)


def shadow_text(surf, text, size, cxy, color, off=2, bold=False,
                shadow=(5, 2, 16)):
    img = text_surf(text, size, color, bold)
    sh = text_surf(text, size, shadow, bold)
    r = img.get_rect(center=cxy)
    surf.blit(sh, (r.x + off, r.y + off))
    surf.blit(img, r)
    return r


def glow_text(surf, text, size, cxy, color, glow=None, bold=True, rings=6):
    """带霓虹光晕的文字"""
    glow = glow or color
    img = text_surf(text, size, color, bold)
    gl = text_surf(text, size, glow, bold)
    r = img.get_rect(center=cxy)
    for i in range(rings):
        a = (i + 1) / rings * math.pi * 2
        d = 2 + i * 0.8
        surf.blit(gl, (r.x + math.cos(a) * d, r.y + math.sin(a) * d),
                  special_flags=pygame.BLEND_ADD)
    surf.blit(gl, r, special_flags=pygame.BLEND_ADD)
    surf.blit(img, r)
    return r


def chroma_title(surf, text, size, cxy, core=(250, 250, 255)):
    """合成波风格标题：粉/青色差偏移 + 白芯"""
    img_c = text_surf(text, size, COL["cyan"], True)
    img_p = text_surf(text, size, COL["pink"], True)
    img_w = text_surf(text, size, core, True)
    r = img_w.get_rect(center=cxy)
    surf.blit(img_p, (r.x - 4, r.y), special_flags=pygame.BLEND_ADD)
    surf.blit(img_c, (r.x + 4, r.y), special_flags=pygame.BLEND_ADD)
    surf.blit(img_w, r)
    return r


# ---------------- 面板 ----------------
def neon_panel(surf, rect, border_col, fill_alpha=86, radius=18, width=2):
    tmp = pygame.Surface(rect.size, pygame.SRCALPHA)
    fill = (*border_col, fill_alpha // 3)
    bord = (*border_col, 235)
    pygame.draw.rect(tmp, (10, 6, 26, fill_alpha), tmp.get_rect(), border_radius=radius)
    pygame.draw.rect(tmp, fill, tmp.get_rect().inflate(-6, -6), border_radius=max(4, radius - 4))
    pygame.draw.rect(tmp, bord, tmp.get_rect(), width=width, border_radius=radius)
    surf.blit(tmp, rect.topleft)


def hline_glow(surf, x1, x2, y, col, w=2):
    pygame.draw.line(surf, col, (x1, y), (x2, y), w + 2)
    pygame.draw.line(surf, COL["white"], (x1 + 8, y), (x2 - 8, y), 1)


# ---------------- 按钮 ----------------
class Button:
    def __init__(self, cxy, label, size=30, w=320, h=62, on_click=None, tag=None):
        self.rect = pygame.Rect(0, 0, w, h)
        self.rect.center = cxy
        self.label = label
        self.font = F(size, True)
        self.on_click = on_click
        self.tag = tag
        self.focused = False
        self.pulse = 0.0

    def contains(self, pos):
        return self.rect.collidepoint(pos)

    def activate(self):
        if self.on_click:
            self.on_click(self.tag)

    def draw(self, surf, t):
        hot = self.focused
        base = COL["purple"] if not hot else COL["cyan"]
        pulse = 1.0 + (math.sin(t * 5 + self.pulse) * 0.5 + 0.5) * 0.25 if hot else 1.0
        tmp = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        rr = tmp.get_rect()
        if hot:
            pygame.draw.rect(tmp, (0, 229, 255, 40), rr.inflate(-8, -8), border_radius=14)
            pygame.draw.rect(tmp, (0, 229, 255, int(70 * pulse)), rr.inflate(4, 4), width=6, border_radius=16)
        else:
            pygame.draw.rect(tmp, (120, 70, 200, 46), rr.inflate(-10, -10), border_radius=14)
        pygame.draw.rect(tmp, (*base[:3], 230), rr, width=2, border_radius=14)
        surf.blit(tmp, self.rect.topleft)
        # 文字
        lab = self.font.render(self.label, True, COL["white"] if hot else (205, 200, 240))
        lr = lab.get_rect(center=rr.center)
        surf.blit(lab, (self.rect.x + lr.x, self.rect.y + lr.y))
        if hot:  # 两侧箭头
            cy = self.rect.centery
            for dx, flip in ((26, False), (self.rect.w - 26, True)):
                pts = [(dx - 7, cy - 8), (dx + 6, cy), (dx - 7, cy + 8)] if not flip else \
                      [(dx + 7, cy - 8), (dx - 6, cy), (dx + 7, cy + 8)]
                pts = [(px + self.rect.x, py) for px, py in pts]
                pygame.draw.polygon(surf, COL["cyan"], pts)
