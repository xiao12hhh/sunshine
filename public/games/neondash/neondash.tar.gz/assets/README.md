# 🌃 霓虹疾驰 Neon Dash

> 一款三跑道假 3D 视角的霓虹赛博风无尽跑酷游戏 —— Python + pygame 打造，零素材纯代码渲染，免安装单文件即可游玩。

![Python](https://img.shields.io/badge/Python-3.10+-blue) ![pygame](https://img.shields.io/badge/pygame--ce-2.5.x-green) ![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey) ![License](https://img.shields.io/badge/License-MIT-yellow)

## ✨ 特性

- 🏃 **三车道假 3D 视角**：透视投影渲染的赛博大道，路侧霓虹灯柱、广告牌、城市剪影随速度飞驰
- 🎮 **完整操控**：切换车道 / 跳跃 / 滑铲 / 急坠，带 **预输入缓冲**（落地前 0.14s 内按跳自动起跳）与腾空拉伸的果冻感动画
- 🧱 **四种障碍 × 三种道具**：跨栏（跳）、吊门（铲）、高墙（闪）；护盾、磁铁、×2 分数
- 🖥️ **四套风格统一的界面**：主菜单（合成波色差标题）、游戏 HUD、暂停面板、结算面板（新纪录庆祝动画）
- 🏆 **计分与存档**：距离实时计分，历史最佳自动保存到本地 JSON，无需登录
- 🔊 **零音频素材**：所有音效由代码实时合成（跳跃/金币/道具/撞击/破纪录号角）
- ⚡ **难度曲线**：速度随时间提升，障碍密度与组合模式动态变化，且保证每波必有活路

## 🚀 快速开始

### 方式一：直接游玩（推荐）

下载 Release 中的 `NeonDash.exe`，双击即玩（Windows 10/11，无需安装任何依赖）。

### 方式二：从源码运行

```bash
pip install pygame-ce
python main.py
```

## ⌨️ 操作说明

| 按键 | 动作 |
|------|------|
| ← / → 或 A / D | 切换跑道 |
| 空格 / ↑ / W | 跳跃（越过粉色**跨栏**；空中按下会缓冲，落地立即起跳） |
| ↓ / S | 滑铲（钻过黄色**吊门**）；空中按下 = 急坠落地滑铲 |
| P 或 Esc | 暂停 / 继续 |
| 鼠标 | 点击菜单按钮 |

## 🎯 场景元素

| 元素 | 应对方式 |
|------|----------|
| 🟥 粉色跨栏 | 跳过去 |
| 🟨 黄色吊门 | 滑铲钻过 |
| 🟪 紫色高墙 | 变道躲避 |
| 🟡 金色六边形 | 能量（+40 分，×2 时翻倍） |
| 🛡 护盾 | 抵挡一次撞击 |
| 🧲 磁铁 | 自动吸取附近能量（8 秒） |
| ✖️ ×2 | 分数加倍（8 秒） |

## 💾 计分与存档

- 分数 = 奔跑距离实时累积 + 能量加成，奔跑速度持续上升
- 结算界面展示本次得分、距离、收集能量与历史最佳，破纪录有专属庆祝动画
- 存档写入程序同目录 `neondash_save.json`，删除该文件即重置纪录

## 🔨 构建打包

```bash
pip install pygame-ce pyinstaller
python main.py --selftest        # 运行 20 项无头自测
python -m PyInstaller --noconfirm --onefile --windowed --name NeonDash main.py
# 产物位于 dist/NeonDash.exe
```

## 📁 项目结构

```
NeonDash/
├── main.py        # 入口：游戏主循环 / --selftest 无头自测
├── config.py      # 全局配置、调色板、伪3D投影函数
├── game.py        # 状态机（菜单/倒计时/奔跑/死亡/结算/暂停）、HUD、碰撞
├── world.py       # 世界渲染（天空/网格/景物）与关卡模式生成器
├── player.py      # 玩家物理（跳/铲/急坠/预输入）与角色渲染
├── ui.py          # 字体、发光文字、霓虹面板、按钮组件
├── sfx.py         # 纯代码合成音效
└── savegame.py    # 本地最高分存档
```

## 🧪 自测

内置 20 项断言覆盖全部状态机与核心玩法逻辑：

```bash
python main.py --selftest   # 输出 SELFTEST 20/20 即通过
```

## 📄 许可证

[MIT](LICENSE)
