# -*- coding: utf-8 -*-
"""伪3D世界：天空/城市预渲染、地面网格、车道虚线、路侧景物、
障碍（跨栏/吊门/高墙）与道具（能量/护盾/磁铁/×2）的生成与绘制。
所有实体使用绝对赛道坐标 T，渲染时换算 rel = T - dist。"""
import math
import random

import pygame

from config import (COL, DRAW_DIST, GATE_CLEAR, HORIZON, HURDLE_CLEAR,
                    LANES, LANE_SPACING, ROAD_HALF, SPEED_MAX, SPEED_START,
                    WALL_H, clamp, fog_col, lerp, project, pseudo_rand)

# 道具类型
COIN, SHIELD, MAGNET, X2 = "coin", "shield", "magnet", "x2"


class Obstacle:
    __slots__ = ("kind", "lane", "T", "seed")

    def __init__(self, kind, lane, T):
        self.kind = kind      # hurdle / gate / wall
        self.lane = lane
        self.T = T
        self.seed = random.random() * 6.28


class Pickup:
    __slots__ = ("kind", "lane", "T", "x", "y", "taken")

    def __init__(self, kind, lane, T, y=0.0):
        self.kind = kind
        self.lane = lane
        self.T = T
        self.x = LANES[lane]
        self.y = y
        self.taken = False


class World:
    def __init__(self):
        self.obstacles = []
        self.pickups = []
        self.frontier = 0.0
        self.safe_until = 0.0
        self._sky = None
        self._build_sky()

    def reset(self, start_dist):
        self.obstacles.clear()
        self.pickups.clear()
        self.frontier = start_dist + 48.0     # 开局一段空跑道
        self.safe_until = start_dist + 240.0  # 前240米只出单一简单障碍

    # ================= 生成 =================
    def difficulty(self, speed):
        return clamp((speed - SPEED_START) / (SPEED_MAX - SPEED_START), 0, 1)

    def add_obstacle(self, kind, lane, T):
        ob = Obstacle(kind, lane, T)
        self.obstacles.append(ob)
        return ob

    def _coin_line(self, lane, T0, n, gap, y):
        for i in range(n):
            self.pickups.append(Pickup(COIN, lane, T0 + i * gap, y))

    def _coin_arc(self, lane, Tc):
        for dt_, y in ((-3.2, 1.15), (-1.6, 1.78), (0, 2.08),
                       (1.6, 1.78), (3.2, 1.15)):
            self.pickups.append(Pickup(COIN, lane, Tc + dt_, y))

    def _free_lanes(self, occupied):
        return [l for l in range(3) if l not in occupied]

    def fill(self, dist, speed):
        """把关卡内容补到视野之外，并清理身后实体"""
        limit = dist + DRAW_DIST + 18
        while self.frontier < limit:
            self.frontier += self._gen(self.frontier, speed)
        cut = dist - 6
        self.obstacles = [o for o in self.obstacles if o.T > cut]
        self.pickups = [p for p in self.pickups if p.T > cut and not p.taken]

    def _gen(self, T, speed):
        d = self.difficulty(speed)
        u = random.uniform
        if T < self.safe_until:
            lane = random.randrange(3)
            kind = "hurdle" if random.random() < 0.55 else "gate"
            self.add_obstacle(kind, lane, T)
            others = self._free_lanes({lane})
            if kind == "hurdle":
                self._coin_arc(lane, T)
                self._coin_line(random.choice(others), T - 3.0, 4, 1.8, 0.55)
            else:
                self._coin_line(lane, T - 3.0, 5, 1.6, 0.52)  # 引导滑铲
                self._coin_line(random.choice(others), T - 2.4, 3, 1.8, 0.55)
            return 16 + u(0, 5)

        r = random.random()
        if r < 0.23:      # 跨栏阵
            n = 1 if (d < 0.3 or random.random() < 0.55) else 2
            lanes = random.sample(range(3), n)
            for ln in lanes:
                self.add_obstacle("hurdle", ln, T + u(-0.6, 0.6))
            self._coin_arc(lanes[0], T + lanes[0] * 0)
            fl = self._free_lanes(set(lanes))
            if fl:
                self._coin_line(random.choice(fl), T - 3.0, 4, 1.8, 0.55)
            return lerp(15.0, 9.5, d) + u(0, 3)

        elif r < 0.45:    # 吊门阵（滑铲）
            n = 1 if (d < 0.3 or random.random() < 0.5) else 2
            lanes = random.sample(range(3), n)
            for ln in lanes:
                self.add_obstacle("gate", ln, T + u(-0.6, 0.6))
            self._coin_line(lanes[0], T - 3.2, 5, 1.6, 0.52)
            return lerp(15.0, 10.0, d) + u(0, 3)

        elif r < 0.64:    # 高墙（变道）
            n = 1 if (d < 0.28 or random.random() < 0.4) else 2
            lanes = random.sample(range(3), n)
            for ln in lanes:
                self.add_obstacle("wall", ln, T)
            fl = self._free_lanes(set(lanes))
            if fl:
                self._coin_line(random.choice(fl), T - 3.5, 5, 1.7, 0.55)
            return lerp(17.0, 11.0, d) + u(0, 3)

        elif r < 0.79:    # 混合排：一堵墙 + 一个跨栏/吊门
            wl = random.randrange(3)
            rest = self._free_lanes({wl})
            ol = random.choice(rest)
            self.add_obstacle("wall", wl, T)
            self.add_obstacle("hurdle" if random.random() < 0.5 else "gate",
                              ol, T + 0.2)
            cl = [l for l in rest if l != ol]
            if cl:
                self._coin_line(cl[0], T - 3.0, 4, 1.7, 0.55)
            return lerp(17.0, 12.0, d) + u(0, 3)

        elif r < 0.91:    # 能量雨（无障碍蛇形金币）
            seq = [random.randrange(3) for _ in range(3)]
            tt = T
            for ln in seq:
                self._coin_line(ln, tt, 4, 1.7, 0.62)
                tt += 7.5
            if random.random() < 0.3:
                self.pickups.append(
                    Pickup(random.choice([SHIELD, MAGNET, X2]),
                           seq[-1], tt + 3.0, 1.15))
            return 26.0

        else:             # 道具补给点
            ln = random.randrange(3)
            kind = random.choice([SHIELD, MAGNET, X2])
            self.pickups.append(Pickup(kind, ln, T, 1.15))
            self._coin_line(ln, T - 4.0, 3, 1.7, 0.62)
            return 13.0

    # ================= 天空预渲染 =================
    def _build_sky(self):
        sky_h = HORIZON + 2
        sky = pygame.Surface((1280, sky_h))
        top, mid, low = COL["bg_top"], COL["bg_mid"], COL["bg_low"]
        for yy in range(sky_h):
            t = yy / sky_h
            if t < 0.62:
                k = t / 0.62
                c = (int(lerp(top[0], mid[0], k)), int(lerp(top[1], mid[1], k)),
                     int(lerp(top[2], mid[2], k)))
            else:
                k = (t - 0.62) / 0.38
                c = (int(lerp(mid[0], low[0], k)), int(lerp(mid[1], low[1], k)),
                     int(lerp(mid[2], low[2], k)))
            pygame.draw.line(sky, c, (0, yy), (1279, yy))
        rnd = random.Random(7)
        for _ in range(130):  # 星星
            x, y = rnd.randint(0, 1279), rnd.randint(0, int(sky_h * 0.72))
            b = rnd.randint(90, 220)
            sky.set_at((x, y), (b, b, min(255, b + 30)))
        # 行星 + 光环
        pcx, pcy, pr_ = int(1280 * 0.74), int(sky_h * 0.42), 64
        for rr, cc in ((pr_ + 26, (60, 20, 110)), (pr_ + 14, (96, 34, 160)),
                       (pr_, (150, 60, 210))):
            pygame.draw.circle(sky, cc, (pcx, pcy), rr)
        pygame.draw.circle(sky, (210, 120, 255), (pcx, pcy), pr_, 3)
        ring = pygame.Rect(0, 0, int(pr_ * 2.6), int(pr_ * 0.62))
        ring.center = (pcx, pcy)
        pygame.draw.arc(sky, (0, 229, 255), ring.inflate(10, 6), math.pi * 1.05, math.pi * 1.95, 3)
        pygame.draw.arc(sky, (0, 160, 200), ring.inflate(26, 16), math.pi * 1.02, math.pi * 1.98, 2)
        # 远近两层城市剪影
        for base_col, hmin, hmax, win_a in (((22, 11, 44), 40, 96, 60),
                                            ((34, 15, 66), 18, 58, 130)):
            x = -20
            while x < 1300:
                bw = rnd.randint(30, 84)
                bh = rnd.randint(hmin, hmax)
                rect = pygame.Rect(x, sky_h - bh, bw, bh)
                pygame.draw.rect(sky, base_col, rect)
                pygame.draw.line(sky, tuple(min(255, c + 26) for c in base_col),
                                 (x, rect.top), (x + bw, rect.top))
                for _ in range(int(bw * bh / 260)):  # 点点灯火
                    wx = rnd.randint(x + 3, x + bw - 5)
                    wy = rnd.randint(rect.top + 4, sky_h - 6)
                    cc = rnd.choice([(255, 90, 180), (90, 230, 255), (255, 210, 120)])
                    lit = tuple(min(255, int(c * win_a / 100) + 18) for c in cc)
                    sky.fill(lit, (wx, wy, 2, 2))
                x += bw + rnd.randint(2, 14)
        self._sky = sky

    # ================= 背景 / 地面 =================
    def draw_background(self, surf, t):
        surf.blit(self._sky, (0, 0))
        # 几颗闪烁星
        for i in range(6):
            a = pseudo_rand(i * 31 + int(t * 2.2)) * 0.9 + 0.1
            x = int(pseudo_rand(i * 97) * 1279)
            y = int(pseudo_rand(i * 53) * HORIZON * 0.6)
            b = int(120 + 135 * a)
            surf.fill((b, b, 255), (x, y, 2, 2))

    def draw_ground(self, surf, dist, focal, cx):
        gh = 720 - HORIZON
        pygame.draw.rect(surf, COL["ground"], (0, HORIZON, 1280, gh + 2))
        zn, zf = -2.2, DRAW_DIST
        _, xl_n, yn = project(-ROAD_HALF, 0, zn, focal, cx)
        _, xr_n, _ = project(ROAD_HALF, 0, zn, focal, cx)
        _, xl_f, yf = project(-ROAD_HALF, 0, zf, focal, cx)
        _, xr_f, _ = project(ROAD_HALF, 0, zf, focal, cx)
        pygame.draw.polygon(surf, COL["road"],
                            [(xl_n, yn), (xr_n, yn), (xr_f, yf), (xl_f, yf)])
        # 横向扫描网格线（全地面宽度）
        step = 8.0
        t0 = math.ceil((dist - 2.2) / step) * step
        tt = t0
        while tt - dist < DRAW_DIST:
            rel = tt - dist
            _, x1, y1 = project(-(ROAD_HALF + 7), 0, rel, focal, cx)
            _, x2, _ = project(ROAD_HALF + 7, 0, rel, focal, cx)
            c = fog_col(COL["grid"], rel)
            wdt = 1 + int(2 * clamp(1.0 - rel / DRAW_DIST, 0, 1))
            pygame.draw.line(surf, c, (x1, y1), (x2, y1), wdt)
            tt += step
        # 车道分隔虚线
        dash, period = 1.7, 3.4
        t1 = math.ceil((dist - 2.2) / period) * period
        for dx_ in (-LANE_SPACING / 2, LANE_SPACING / 2):
            tt = t1
            while tt - dist < DRAW_DIST:
                a = max(tt - dist, -2.2)
                b_ = tt + dash - dist
                if b_ <= a:
                    tt += period
                    continue
                _, xa, ya = project(dx_, 0, a, focal, cx)
                _, xb, yb = project(dx_, 0, b_, focal, cx)
                c = fog_col((70, 190, 215), (a + b_) / 2)
                pygame.draw.line(surf, c, (xa, ya), (xb, yb),
                                 1 + int(2 * clamp(1.0 - abs(a) / DRAW_DIST, 0, 1)))
                tt += period
        # 两侧霓虹轨道
        for side, col_main in ((-1, COL["rail_cyan"]), (1, COL["rail_pink"])):
            x_edge = ROAD_HALF * side
            _, xe_n, ye_n = project(x_edge, 0, zn, focal, cx)
            _, xe_f, ye_f = project(x_edge, 0, zf, focal, cx)
            pygame.draw.line(surf, fog_col(col_main, 26), (xe_n, ye_n), (xe_f, ye_f), 6)
            pygame.draw.line(surf, fog_col(COL["white"], 20), (xe_n, ye_n), (xe_f, ye_f), 2)
            xa_ = ROAD_HALF * side + 0.42 * side
            _, xn2, yn2 = project(xa_, 0, zn, focal, cx)
            _, xf2, yf2 = project(xa_, 0, zf, focal, cx)
            pygame.draw.line(surf, fog_col(col_main, 40), (xn2, yn2), (xf2, yf2), 2)

    def draw_scenery(self, surf, dist, focal, cx, t):
        step = 12.0
        i0 = int(math.ceil((dist - 2) / step))
        i = i0
        while (i * step) - dist < DRAW_DIST:
            rel = i * step - dist
            if rel > -2.0:
                side = 1 if i % 2 == 0 else -1
                r1 = pseudo_rand(i * 13 + 5)
                r2 = pseudo_rand(i * 71 + 9)
                xw = side * (5.0 + r1 * 3.2)
                h = 2.6 + r2 * 4.8
                _, bx, by = project(xw, 0, rel, focal, cx)
                _, tx, ty = project(xw, h, rel, focal, cx)
                c = fog_col((150, 62, 224), rel)
                pygame.draw.line(surf, c, (bx, by), (tx, ty),
                                 1 + int(3 * clamp(1 - rel / DRAW_DIST, 0, 1)))
                lamp_c = fog_col(COL["cyan"] if i % 4 < 2 else COL["pink"], rel)
                lr = 1 + int(3 * clamp(1 - rel / DRAW_DIST, 0, 1))
                pygame.draw.circle(surf, lamp_c, (int(tx), int(ty)), lr)
                if pseudo_rand(i * 37 + 77) < 0.20:   # 广告牌光板
                    bw = 1.5 + r1
                    _, mx, my = project(xw, h * 0.55, rel, focal, cx)
                    w2, h2 = bw * focal / (rel + 7), 0.9 * focal / (rel + 7)
                    flick = 0.75 + 0.25 * math.sin(t * 7 + i)
                    cc = fog_col((int(255 * flick), 60, 160) if i % 2 else
                                 (60, int(235 * flick), 255), rel)
                    pygame.draw.rect(surf, cc, (mx - w2 / 2, my - h2 / 2, w2, h2), 1)
            i += 1

    # ================= 实体绘制 =================
    def draw_entities(self, surf, dist, focal, cx, t):
        items = []
        for ob in self.obstacles:
            rel = ob.T - dist
            if -1.0 < rel < DRAW_DIST:
                items.append((rel, 0, ob))
        for pk in self.pickups:
            rel = pk.T - dist
            if -0.6 < rel < DRAW_DIST and not pk.taken:
                items.append((rel, 1, pk))
        items.sort(key=lambda e: e[0], reverse=True)  # 由远及近
        for rel, typ, ent in items:
            if typ == 0:
                if ent.kind == "hurdle":
                    self._draw_hurdle(surf, ent, rel, focal, cx, t)
                elif ent.kind == "gate":
                    self._draw_gate(surf, ent, rel, focal, cx, t)
                else:
                    self._draw_wall(surf, ent, rel, focal, cx, t)
            else:
                if ent.kind == COIN:
                    self._draw_coin(surf, ent, rel, focal, cx, t)
                else:
                    self._draw_power(surf, ent, rel, focal, cx, t)

    def _draw_hurdle(self, surf, ob, rel, focal, cx, t):
        s, bx, by = project(LANES[ob.lane], 0, rel, focal, cx)
        w = 1.7 * s
        hp = HURDLE_CLEAR * s
        col = fog_col(COL["pink"], rel)
        dk = fog_col((120, 20, 70), rel)
        # 支柱
        pygame.draw.line(surf, dk, (bx - w * 0.42, by), (bx - w * 0.42, by - hp), max(1, int(s * 0.04)))
        pygame.draw.line(surf, dk, (bx + w * 0.42, by), (bx + w * 0.42, by - hp), max(1, int(s * 0.04)))
        # 发光横杆
        glow = pygame.Surface((int(w) + 14, int(max(3, hp * 0.34)) + 12), pygame.SRCALPHA)
        pygame.draw.rect(glow, (*COL["pink"], 60), glow.get_rect(), border_radius=8)
        surf.blit(glow, (bx - glow.get_width() / 2, by - hp - 5))
        br = pygame.Rect(bx - w / 2, by - hp, w, max(3, hp * 0.30))
        pygame.draw.rect(surf, col, br, border_radius=max(1, int(s * 0.03)))
        pygame.draw.line(surf, fog_col(COL["white"], rel),
                         (br.x + 3, br.y + 1), (br.right - 3, br.y + 1), 1)
        if rel < 16 and int(t * 6) % 2 == 0:  # 近处警示闪灯
            pygame.draw.circle(surf, COL["white"], (int(bx - w * 0.36), br.centery), max(1, int(s * 0.03)))
            pygame.draw.circle(surf, COL["white"], (int(bx + w * 0.36), br.centery), max(1, int(s * 0.03)))

    def _draw_gate(self, surf, ob, rel, focal, cx, t):
        s, bx, by = project(LANES[ob.lane], 0, rel, focal, cx)
        w = 1.95 * s
        y_top = WALL_H
        y_bot = GATE_CLEAR
        ty = by - y_top * s
        byy = by - y_bot * s
        col = fog_col(COL["yellow"], rel)
        dkf = fog_col((96, 74, 20), rel)
        rect = pygame.Rect(bx - w / 2, ty, w, byy - ty)
        # 两侧立柱
        pole = fog_col((150, 120, 40), rel)
        pygame.draw.line(surf, pole, (bx - w / 2, by), (bx - w / 2, ty), max(1, int(s * 0.05)))
        pygame.draw.line(surf, pole, (bx + w / 2, by), (bx + w / 2, ty), max(1, int(s * 0.05)))
        # 门体
        pygame.draw.rect(surf, dkf, rect)
        pygame.draw.rect(surf, col, rect, max(1, int(s * 0.035)))
        stripe_c = fog_col((70, 56, 16), rel)
        for k in range(1, 4):  # 内部条纹
            yy = rect.y + rect.h * k / 4
            pygame.draw.line(surf, stripe_c, (rect.x + 4, yy), (rect.right - 4, yy), 1)
        # 底沿发光条
        pygame.draw.line(surf, col, (rect.x, rect.bottom), (rect.right, rect.bottom),
                         max(1, int(s * 0.05)))
        if rel < 15:
            blink = int(t * 6) % 2 == 0
            pygame.draw.circle(surf, COL["danger"] if blink else fog_col(COL["danger"], rel),
                               (rect.centerx, rect.bottom - 2), max(1, int(s * 0.045)))

    def _draw_wall(self, surf, ob, rel, focal, cx, t):
        lx = LANES[ob.lane]
        dep = 0.9
        sF, fbl_x, fb_y = project(lx - 0.93, 0, rel, focal, cx)
        _, fbr_x, _ = project(lx + 0.93, 0, rel, focal, cx)
        _, ftl_y = project(lx - 0.93, WALL_H, rel, focal, cx)[1:]
        _, ftr_y = project(lx + 0.93, WALL_H, rel, focal, cx)[1:]
        sB, bbl_x, bb_y = project(lx - 0.86, 0, rel + dep, focal, cx)
        _, bbr_x, _ = project(lx + 0.86, 0, rel + dep, focal, cx)
        _, btl_y = project(lx - 0.86, WALL_H, rel + dep, focal, cx)[1:]
        _, btr_y = project(lx + 0.86, WALL_H, rel + dep, focal, cx)[1:]
        face = fog_col((88, 30, 150), rel)
        face_dk = fog_col((56, 18, 100), rel)
        edge = fog_col(COL["purple"], rel)
        # 顶面与侧面
        pygame.draw.polygon(surf, face_dk,
                            [(fbl_x, ftl_y), (fbr_x, ftr_y), (bbr_x, btr_y), (bbl_x, btl_y)])
        pygame.draw.polygon(surf, face_dk,
                            [(fbr_x, fb_y), (fbr_x, ftr_y), (bbr_x, btr_y), (bbr_x, bb_y)])
        # 正面
        pygame.draw.polygon(surf, face,
                            [(fbl_x, fb_y), (fbr_x, fb_y), (fbr_x, ftr_y), (fbl_x, ftl_y)])
        pygame.draw.lines(surf, edge, True,
                          [(fbl_x, fb_y), (fbr_x, fb_y), (fbr_x, ftr_y), (fbl_x, ftl_y)], 2)
        # 脉冲能量核心
        pul = 0.55 + 0.45 * math.sin(t * 6 + ob.seed)
        ccx = (fbl_x + fbr_x) / 2
        ccy = (fb_y + ftl_y) / 2
        cr = max(2, (fb_y - ftl_y) * 0.16 * (0.8 + 0.4 * pul))
        pc = fog_col((int(255 * (0.5 + pul * 0.5)), 50, 170), rel)
        pygame.draw.polygon(surf, pc, [
            (ccx, ccy - cr), (ccx + cr * 0.7, ccy), (ccx, ccy + cr), (ccx - cr * 0.7, ccy)])

    def _draw_coin(self, surf, pk, rel, focal, cx, t):
        bob = math.sin(t * 3.1 + pk.T * 0.7) * 0.10
        s, px, py = project(pk.x, pk.y + bob, rel, focal, cx)
        r = 0.30 * s
        if r < 1.2:
            return
        spin = abs(math.cos(t * 5.0 + pk.T))
        col = fog_col((255, 208, 64), rel)
        hi = fog_col((255, 245, 200), rel)
        pts = []
        for k in range(6):
            a = math.pi / 6 + k * math.pi / 3
            pts.append((px + math.cos(a) * r * max(0.22, spin),
                        py + math.sin(a) * r))
        glow = pygame.Surface((int(r * 3.4), int(r * 3.4)), pygame.SRCALPHA)
        pygame.draw.circle(glow, (255, 200, 60, 55), glow.get_rect().center, int(glow.get_width() / 2 - 2))
        surf.blit(glow, (px - glow.get_width() / 2, py - glow.get_height() / 2))
        pygame.draw.polygon(surf, col, pts)
        pygame.draw.polygon(surf, hi,
                            [(px + (q[0] - px) * 0.45, py + (q[1] - py) * 0.45) for q in pts])

    def _draw_power(self, surf, pk, rel, focal, cx, t):
        bob = math.sin(t * 2.4 + pk.T) * 0.14
        s, px, py = project(pk.x, pk.y + bob, rel, focal, cx)
        r = 0.42 * s
        if r < 2:
            return
        colmap = {SHIELD: COL["cyan"], MAGNET: COL["pink"], X2: COL["yellow"]}
        col = fog_col(colmap[pk.kind], rel)
        rot = math.sin(t * 2.2 + pk.T) * 0.22
        glow = pygame.Surface((int(r * 4), int(r * 4)), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*col[:3], 70), glow.get_rect().center, int(glow.get_width() / 2 - 2))
        surf.blit(glow, (px - glow.get_width() / 2, py - glow.get_height() / 2))
        # 外壳：旋转圆角方框
        pts = []
        for dx_, dy_ in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            a = rot
            rx = dx_ * r * 0.82
            ry = dy_ * r * 0.82
            qx = px + rx * math.cos(a) - ry * math.sin(a)
            qy = py + rx * math.sin(a) + ry * math.cos(a)
            pts.append((qx, qy))
        pygame.draw.polygon(surf, col, pts, max(1, int(r * 0.14)))
        # 内部图标
        ir = r * 0.42
        if pk.kind == SHIELD:
            hexpts = [(px + math.cos(k * math.pi / 3) * ir,
                       py + math.sin(k * math.pi / 3) * ir) for k in range(6)]
            pygame.draw.polygon(surf, col, hexpts, 2)
            pygame.draw.polygon(surf, (*col[:3], ), hexpts, 1)
        elif pk.kind == MAGNET:
            rect = pygame.Rect(px - ir, py - ir * 0.9, ir * 2, ir * 1.8)
            pygame.draw.arc(surf, col, rect, 0, math.pi, max(2, int(ir * 0.5)))
            pygame.draw.line(surf, col, (px - ir, py), (px - ir, py + ir * 0.4), max(2, int(ir * 0.5)))
            pygame.draw.line(surf, col, (px + ir, py), (px + ir, py + ir * 0.4), max(2, int(ir * 0.5)))
        else:  # ×2
            f = pygame.font.Font(None, max(10, int(r * 1.1)))
            img = f.render("x2", True, col)
            surf.blit(img, img.get_rect(center=(px, py)))
