# -*- coding: utf-8 -*-
"""本地存档：自动保存历史最高分等信息，JSON 格式，无需登录。
优先写在程序同目录（便携），不可写时回退到用户目录 / 内存。
网页版（pygbag/wasm）没有可写文件系统，自动退化为内存档（本次会话有效）。"""
import json
import os
import sys
import tempfile


def _is_web():
    """pygbag 编译的 wasm 环境特征：无真实文件系统"""
    try:
        import platform
        return platform.system() in ("Emscripten", "emscripten", "JavaScript")
    except Exception:
        return False


def _candidate_dirs():
    dirs = []
    if _is_web():
        return dirs  # 网页版不尝试文件系统
    try:
        if getattr(sys, "frozen", False):
            dirs.append(os.path.dirname(os.path.abspath(sys.executable)))
        else:
            dirs.append(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        pass
    home = os.path.expanduser("~")
    if home:
        dirs.append(home)
    dirs.append(tempfile.gettempdir())
    return dirs


class SaveGame:
    DEFAULTS = {"best_score": 0, "best_distance": 0.0,
                "games": 0, "total_coins": 0}

    def __init__(self):
        self.data = dict(self.DEFAULTS)
        self.path = None
        self.load()

    # ---------- 路径 ----------
    def _pick_path(self):
        for d in _candidate_dirs():
            try:
                p = os.path.join(d, "neondash_save.json")
                # 探测目录是否可写
                probe = os.path.join(d, ".nd_probe")
                with open(probe, "w") as f:
                    f.write("ok")
                os.remove(probe)
                return p
            except Exception:
                continue
        return None

    # ---------- localStorage（网页版持久化）----------
    @staticmethod
    def _get_ls():
        """wasm 环境通过 js 桥访问 localStorage；桌面版/失败返回 None"""
        try:
            import js  # pygbag 提供的浏览器 js 桥
            ls = js.window.localStorage
            # 确保对象可用（有些环境无 window）
            if ls is None:
                return None
            ls.getItem("_nd_probe")
            return ls
        except Exception:
            return None

    def _load_from_ls(self):
        try:
            ls = self._get_ls()
            if ls is None:
                return False
            raw_text = ls.getItem("neondash_save")
            if not raw_text:
                return False
            raw = json.loads(str(raw_text))
            for k, dv in self.DEFAULTS.items():
                v = raw.get(k, dv)
                if isinstance(v, (int, float)) and v >= 0:
                    self.data[k] = v
            return True
        except Exception:
            return False

    def _save_to_ls(self):
        try:
            ls = self._get_ls()
            if ls is None:
                return False
            ls.setItem("neondash_save", json.dumps(self.data, ensure_ascii=False))
            return True
        except Exception:
            return False

    # ---------- 读写 ----------
    def load(self):
        # 网页版：localStorage
        if _is_web():
            self.path = None
            self._load_from_ls()
            return self.data
        self.path = self._pick_path()
        if self.path and os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                for k, dv in self.DEFAULTS.items():
                    v = raw.get(k, dv)
                    if isinstance(v, (int, float)) and v >= 0:
                        self.data[k] = v
            except Exception:
                pass  # 存档损坏则视为新档
        return self.data

    def save(self):
        # 网页版：localStorage
        if _is_web():
            return self._save_to_ls()
        if not self.path:
            return False
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=1)
            return True
        except Exception:
            return False

    # ---------- 业务 ----------
    @property
    def best_score(self):
        return int(self.data["best_score"])

    @property
    def best_distance(self):
        return float(self.data["best_distance"])

    def submit(self, score, distance, coins):
        """结算一次跑局；返回是否刷新了最佳分纪录"""
        self.data["games"] = int(self.data.get("games", 0)) + 1
        self.data["total_coins"] = int(self.data.get("total_coins", 0)) + int(coins)
        record = score > self.best_score
        if record:
            self.data["best_score"] = int(score)
        if distance > self.data["best_distance"]:
            self.data["best_distance"] = round(float(distance), 1)
        self.save()
        return record
