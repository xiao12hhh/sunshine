# -*- coding: utf-8 -*-
"""霓虹疾驰 Neon Dash —— 入口：正常启动 / --selftest 无头自测"""
import os
import sys
import traceback

SELFTEST = "--selftest" in sys.argv
if SELFTEST:
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame

from config import FPS, TITLE, H, W


def make_screen():
    return pygame.display.set_mode((W, H))


def run_normal():
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    pygame.display.set_caption(TITLE)
    screen = make_screen()
    clock = pygame.time.Clock()
    from game import Game
    g = Game(screen)
    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000.0, 1 / 45.0)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                g.handle_keydown(e.key)
            elif e.type == pygame.MOUSEMOTION:
                g.handle_mouse_motion(e.pos)
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                g.handle_mouse_down(e.pos)
        g.update(dt)
        g.draw()
    pygame.quit()


def run_selftest():
    """无头自测：跑通 状态机 / 操控 / 碰撞死亡 / 存档 / 暂停续玩 全流程"""
    import random
    random.seed(7)
    pygame.init()
    pygame.display.set_caption("neondash-selftest")
    screen = make_screen()
    from game import Game
    g = Game(screen)
    results = []

    def check(name, cond):
        results.append(bool(cond))
        print(("PASS " if cond else "FAIL ") + name, flush=True)

    def step(sec):
        n = max(1, int(round(sec * 60)))
        for _ in range(n):
            g.update(1 / 60.0)
            g.draw()

    try:
        check("01_state_menu", g.state == "menu")
        # 鼠标点击“开始游戏”
        b = g.btns["menu"][0]
        g.handle_mouse_motion(b.rect.center)
        g.handle_mouse_down(b.rect.center)
        step(0.2)
        check("02_start_by_click", g.state == "count")
        step(3.8)
        check("03_run_after_countdown", g.state == "run")
        # 键盘操控
        g.handle_keydown(pygame.K_RIGHT)
        step(0.35)
        check("04_lane_switch", g.player.target_lane == 2)
        g.handle_keydown(pygame.K_SPACE)
        step(0.22)
        check("05_jump_airborne", (not g.player.grounded) or g.player.y > 0)
        step(1.0)
        g.handle_keydown(pygame.K_DOWN)
        step(0.30)
        check("06_slide_or_slam", g.player.slide_t > 0 or not g.player.grounded)
        step(1.6)
        check("07_score_growing", int(g.score_f) > 0 and g.dist > 10)
        # 强制死亡：正对车道生成一堵高墙
        g.buffs["shield"] = 0.0
        g.player.inv_t = 0.0
        g.world.add_obstacle("wall", g.player.target_lane, g.dist + 2.0)
        t0 = g.t
        while g.state == "run" and g.t - t0 < 6:
            step(1 / 60.0)
        check("08_death_on_wall", g.state in ("dying", "over"))
        step(1.4)
        check("09_over_screen", g.state == "over")
        check("10_save_written", g.save.data["games"] >= 1)
        check("11_score_positive", g.final_score > 0)
        best_before = g.save.best_score
        # 结算界面键盘：R 重开
        g.handle_keydown(pygame.K_r)
        step(0.2)
        check("12_retry_to_countdown", g.state == "count")
        check("13_best_kept", g.save.best_score >= best_before)
        step(3.8)
        check("14_running_again", g.state == "run")
        # 暂停/继续
        g.handle_keydown(pygame.K_p)
        step(0.1)
        check("15_paused", g.state == "pause")
        g.handle_keydown(pygame.K_p)
        step(0.1)
        check("16_resumed", g.state == "run")
        g.handle_keydown(pygame.K_ESCAPE)
        step(0.1)
        check("17_pause_by_esc", g.state == "pause")
        g.goto_menu()
        step(0.2)
        check("18_back_to_menu", g.state == "menu")
        # 键盘导航菜单 + 帮助开关
        g.handle_keydown(pygame.K_DOWN)
        g.handle_keydown(pygame.K_RETURN)
        check("19_help_open", g.help_open)
        g.handle_keydown(pygame.K_ESCAPE)
        check("20_help_closed", not g.help_open)
    except Exception:
        traceback.print_exc()
        print("SELFTEST EXCEPTION", flush=True)
        return 2

    passed = sum(results)
    total = len(results)
    print(f"SELFTEST {passed}/{total}", flush=True)
    return 0 if passed == total else 1


if __name__ == "__main__":
    if SELFTEST:
        code = run_selftest()
        try:
            pygame.quit()
        except Exception:
            pass
        sys.exit(code)
    else:
        run_normal()
