# -*- coding: utf-8 -*-
"""音效：纯代码合成（无外部素材），初始化失败时静默降级为无声。"""
import math
import random
import struct

import pygame

_SR = 22050


def _seg(f0, f1, dur, vol=0.3, wave="sin"):
    """生成一段音频字节：频率从 f0 滑到 f1"""
    n = int(_SR * dur)
    buf = bytearray()
    ph = 0.0
    for i in range(n):
        f = f0 + (f1 - f0) * (i / n)
        ph += 2.0 * math.pi * f / _SR
        if wave == "sq":
            v = 1.0 if math.sin(ph) >= 0 else -1.0
        elif wave == "ns":
            v = random.uniform(-1.0, 1.0)
        else:
            v = math.sin(ph)
        attack = min(1.0, i / (_SR * 0.004))
        env = attack * (1.0 - i / n) ** 1.6
        buf += struct.pack("<h", max(-32767, min(32767, int(v * env * vol * 32000))))
    return bytes(buf)


class SFX:
    def __init__(self):
        self.ok = False
        self.enabled = True
        self.sounds = {}
        try:
            info = pygame.mixer.get_init()
            if info is None:
                raise RuntimeError("mixer not initialized")
            self.sounds = {
                "click":  pygame.mixer.Sound(buffer=_seg(760, 480, 0.06, 0.22, "sq")),
                "jump":   pygame.mixer.Sound(buffer=_seg(300, 660, 0.18, 0.32)),
                "coin":   pygame.mixer.Sound(buffer=_seg(1180, 1560, 0.09, 0.20, "sq")),
                "power":  pygame.mixer.Sound(
                    buffer=_seg(520, 520, 0.07, 0.26) + _seg(780, 780, 0.07, 0.26)
                    + _seg(1046, 1046, 0.11, 0.26)),
                "crash":  pygame.mixer.Sound(buffer=_seg(900, 90, 0.45, 0.5, "ns")),
                "switch": pygame.mixer.Sound(buffer=_seg(420, 300, 0.05, 0.12, "sq")),
                "record": pygame.mixer.Sound(
                    buffer=_seg(659, 659, 0.09, 0.26) + _seg(880, 880, 0.09, 0.26)
                    + _seg(1174, 1174, 0.09, 0.26) + _seg(1568, 1568, 0.20, 0.26)),
            }
            self.ok = True
        except Exception:
            self.ok = False

    def play(self, name):
        if self.ok and self.enabled:
            snd = self.sounds.get(name)
            if snd:
                try:
                    snd.play()
                except Exception:
                    pass

    def toggle(self):
        self.enabled = not self.enabled
        return self.enabled
